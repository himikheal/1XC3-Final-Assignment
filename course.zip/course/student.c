/**
 * @file student.c
 * @author Michael Zhang
 * @brief Functions to be used alongside the student struct
 * @version 1.0
 * @date 2022-04-11
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to a student struct
 * 
 * @param student The student whose grades are being changed
 * @param grade The grade to be added
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // Checks if the added grade is the first, to determine whether to use calloc or realloc
  // Calloc is used for the first grade, otherwise, realloc is used
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Returns the student's average
 * 
 * @param student The student whose average is found
 * @return The averages of the student's grades
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Totals the student's grades
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Formats and prints the student's information
 * 
 * @param student The student that is printed
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // Loops through grades and prints them rounded to 2 decimal places
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Randomly generates a student with a combination of 24 first and last names, an id, and an amount of grades
 * 
 * @param grades The number of grades the student has
 * @return The pointer to the student that is generated
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Generates an id
  // Loops through the indices of the id and generates a random character
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  // Indicates the end of a string
  new_student->id[10] = '\0';

  // Generates a number of random grades that are between 25 and 99
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}