/**
 * @file course.c
 * @author Michael Zhang
 * @brief Functions to be used alongside the course struct
 * @version 1.0
 * @date 2022-04-11
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds the given student to the list of students in a course structure and changes the necessary info in the course
 * 
 * @param course A pointer to the course in which the student is to be enrolled
 * @param student The student to be enrolled into a course
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // Checks whether the student is the first student to know to use calloc or realloc
  // Calloc is used for the first student, otherwise, realloc is used
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Formats the information in a course structure and prints it
 * 
 * @param course The course to be printed
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  // Loops through and prints all the students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the student in a course that has the highest average
 * 
 * @param course The course in which the top student is found
 * @return The student in the course with the highest average
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // Loop through all students in the course
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    // Checks if average is the highest so far, if it is, save it
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Returns an array of all the students that are passing
 * 
 * @param course The course on which the function is performed
 * @param total_passing The number of students with an average above or equal to 50
 * @return The array of students with a grade over or equal to 50
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Loops through all students and counts how many have an average >= 50
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  // Allocates an appropriate amount of memory based on the count
  passing = calloc(count, sizeof(Student));

  // Loops through students and assigns them to the passing array if they are passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}