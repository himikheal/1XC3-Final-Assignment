/**
 * @file main.c
 * @author Michael Zhang
 * @brief Demonstrates use of course and student structs as well as the associated functions
 * @version 1.0
 * @date 2022-04-11
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Generates 20 random students and enrolls them into the course MATH101, then proceeds to print the top student and all students that are passing
 */
int main()
{
  srand((unsigned) time(NULL));

  // Allocates new memory for a course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Generates and enrolls 20 random students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // Creates a pointer to the top student in the course and prints them
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Counts how many students are passing and prints them
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}