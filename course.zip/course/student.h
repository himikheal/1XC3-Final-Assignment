/**
 * @file student.h
 * @author Michael Zhang
 * @brief The student structure definition and function definitions
 * @version 1.0
 * @date 2022-04-11
 */ 

/**
 * @brief A structure that represents courses and stores the necessary info
 * 
 * @param first_name The first name of the student
 * @param last_name The last name of the student
 * @param id The student's id
 * @param grades A pointer to an array of the student's grades
 * @param num_grades The number of grades the student has
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
