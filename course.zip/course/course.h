/**
 * @file course.h
 * @author Michael Zhang
 * @brief The course structure definition and function definitions
 * @version 1.0
 * @date 2022-04-11
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief A structure that represents courses and stores the necessary info
 * 
 * @param name The name of the course
 * @param code The course code
 * @param students A pointer to where the students are stored
 * @param total_students The number of students in the course
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


